<?php
require("../assets/vendor/php-email-form/PHPMailer/src/PHPMailer.php");
require("../assets/vendor/php-email-form/PHPMailer/src/SMTP.php");
 $mail = new PHPMailer\PHPMailer\PHPMailer();
 $mail->IsSMTP(); // enable SMTP
 $mail->SMTPDebug = 0; // debugging: 1 = errors and messages, 2 = messages only
 $mail->SMTPAuth = true; // authentication enabled
 $mail->SMTPSecure = 'ssl'; // secure transfer enabled REQUIRED for Gmail
 $mail->Host = 'mail.gryphosplus.com';
 $mail->Port = 465; // or 587
 $mail->IsHTML(true);
 $mail->Username = 'hola@gryphosplus.com';
 $mail->Password = 'Adonai.2014';
 $mail->SetFrom($_POST['email']);
 $mail->Subject = $_POST['subject'];
 $mail->Body = $_POST['message'];
 $mail->AddAddress('hola@gryphosplus.com');
 if(!$mail->Send()) {
 echo "Mailer Error: " . $mail->ErrorInfo;
 } else {
 echo "Mensaje enviado correctamente. Message sent successfully" ;
 }
?>